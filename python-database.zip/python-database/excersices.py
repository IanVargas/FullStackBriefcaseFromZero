import datetime
from bdmanagement import Pg_Manager

connect_to_database = Pg_Manager("poohtazoTesting","localhost","postgres","SaSha310631")


class User:

    def _init_(self,username,email,password,date_of_birth,account_amount):
        self.username = username
        self.email = email
        self.password = password
        self.date_of_birth = date_of_birth
        self.account_amount = account_amount

        try:
            self.create_new_user(username,email,password,date_of_birth,account_amount)
        except Exception as error:
            print("user not created",error)
    def create_new_user(self,username,email,password,date_of_birth,account_amount):
        try:
            query_to_create_user = ("INSERT INTO Lyfter_car_rental.Users(username,email,password,dateOfBirth,acountamount) VALUES(%s, %s, %s, %s, %s)")
            connect_to_database.create_query(query_to_create_user,(username,email,password,date_of_birth,account_amount))
            print("user created")
        except Exception as error:
            print("Not able to create user",error)
    def update_user(self,updates):
        try:
            query = "UPDATE Lyfter_car_rental.Users set {} where username='{}'".format(updates,self.username)
            print(query)
            connect_to_database.create_query(query,"")
            print("updates successfully")
        except Exception as error:
            print("user not updated",error)


user1 = User("ianvargas","ian.porras10@gmail.com","123456","2000/08/31",0)

user1.update_user("username='ian123',password='567'")

#connect_to_database.cursor.execute("UPDATE Lyfter_car_rental.Users set username='ian123',password='567' where username='ianvargas'")
#connect_to_database.connection.commit()


